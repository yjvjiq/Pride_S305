function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <Root>/2-D Lookup
Table4 */
	this.urlHashMap["Feedback240Ah:27"] = "Feedback240Ah.c:28&Feedback240Ah_private.h:44,47,50,53";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "Feedback240Ah"};
	this.sidHashMap["Feedback240Ah"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<Root>/In7"] = {sid: "Feedback240Ah:25"};
	this.sidHashMap["Feedback240Ah:25"] = {rtwname: "<Root>/In7"};
	this.rtwnameHashMap["<Root>/In8"] = {sid: "Feedback240Ah:26"};
	this.sidHashMap["Feedback240Ah:26"] = {rtwname: "<Root>/In8"};
	this.rtwnameHashMap["<Root>/2-D Lookup Table4"] = {sid: "Feedback240Ah:27"};
	this.sidHashMap["Feedback240Ah:27"] = {rtwname: "<Root>/2-D Lookup Table4"};
	this.rtwnameHashMap["<Root>/Out4"] = {sid: "Feedback240Ah:28"};
	this.sidHashMap["Feedback240Ah:28"] = {rtwname: "<Root>/Out4"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
