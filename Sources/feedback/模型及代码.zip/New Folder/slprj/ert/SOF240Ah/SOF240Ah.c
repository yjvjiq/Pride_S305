/*
 * File: SOF240Ah.c
 *
 * Code generated for Simulink model 'SOF240Ah'.
 *
 * Model version                  : 1.26
 * Simulink Coder version         : 8.10 (R2016a) 10-Feb-2016
 * C/C++ source code generated on : Tue Dec 20 17:30:38 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SOF240Ah.h"
#include "SOF240Ah_private.h"

MdlrefDW_SOF240Ah_T SOF240Ah_MdlrefDW;

/* Output and update for referenced model: 'SOF240Ah' */
real32_T SOF240Ah_step(real32_T M240Ah_SOF_Soc, real32_T M240Ah_SOF_T)
{
  /* specified return value */
  real32_T M240Ah_SOF;

  /* Lookup_n-D: '<Root>/2-D Lookup Table3' */
  M240Ah_SOF = look2_iflf_linlcapw(M240Ah_SOF_Soc, M240Ah_SOF_T,
    rtCP_uDLookupTable3_bp01Data, rtCP_uDLookupTable3_bp02Data,
    rtCP_uDLookupTable3_tableData, rtCP_uDLookupTable3_maxIndex, 11U);
  return M240Ah_SOF;
}

/* Model initialize function */
void SOF240Ah_k_initialize(const char_T **rt_errorStatus)
{
  RT_MODEL_SOF240Ah_T *const SOF240Ah_M = &(SOF240Ah_MdlrefDW.rtm);

  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatusPointer(SOF240Ah_M, rt_errorStatus);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
