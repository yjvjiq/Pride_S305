/*
 * File: FT240Ah_private.h
 *
 * Code generated for Simulink model 'FT240Ah'.
 *
 * Model version                  : 1.27
 * Simulink Coder version         : 8.10 (R2016a) 10-Feb-2016
 * C/C++ source code generated on : Tue Dec 20 17:30:46 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_FT240Ah_private_h_
#define RTW_HEADER_FT240Ah_private_h_
#include "rtwtypes.h"
#include "model_reference_types.h"
#endif                                 /* RTW_HEADER_FT240Ah_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
