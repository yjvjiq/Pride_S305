/*
 * File: FT240Ah.c
 *
 * Code generated for Simulink model 'FT240Ah'.
 *
 * Model version                  : 1.27
 * Simulink Coder version         : 8.10 (R2016a) 10-Feb-2016
 * C/C++ source code generated on : Tue Dec 20 17:30:46 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "FT240Ah.h"
#include "FT240Ah_private.h"

/* Exported block signals */
real32_T out1;                         /* '<Root>/Model2' */
real32_T out4;                         /* '<Root>/Model3' */

/* External inputs (root inport signals with auto storage) */
ExtU_FT240Ah_T FT240Ah_U;

/* Real-time model */
RT_MODEL_FT240Ah_T FT240Ah_M_;
RT_MODEL_FT240Ah_T *const FT240Ah_M = &FT240Ah_M_;

/* Model step function */
void FT240Ah_step(void)
{
  /* ModelReference: '<Root>/Model2' */
  out1 = SOF240Ah_step(FT240Ah_U.In1, FT240Ah_U.In2);

  /* ModelReference: '<Root>/Model3' */
  out4 = Feedback240Ah_step(FT240Ah_U.In7, FT240Ah_U.In8);
}

/* Model initialize function */
void FT240Ah_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(FT240Ah_M, (NULL));

  /* block I/O */

  /* exported global signals */
  out1 = 0.0F;
  out4 = 0.0F;

  /* external inputs */
  (void) memset((void *)&FT240Ah_U, 0,
                sizeof(ExtU_FT240Ah_T));

  /* Model Initialize fcn for ModelReference Block: '<Root>/Model2' */
  SOF240Ah_k_initialize(rtmGetErrorStatusPointer(FT240Ah_M));

  /* Model Initialize fcn for ModelReference Block: '<Root>/Model3' */
  Feedback240Ah_i_initialize(rtmGetErrorStatusPointer(FT240Ah_M));
}

/* Model terminate function */
void FT240Ah_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
