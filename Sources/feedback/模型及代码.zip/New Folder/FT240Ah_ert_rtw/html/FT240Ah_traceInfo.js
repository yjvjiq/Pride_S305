function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <Root>/In1 */
	this.urlHashMap["FT240Ah:22"] = "FT240Ah.h:51";
	/* <Root>/In2 */
	this.urlHashMap["FT240Ah:23"] = "FT240Ah.h:52";
	/* <Root>/In7 */
	this.urlHashMap["FT240Ah:32"] = "FT240Ah.h:53";
	/* <Root>/In8 */
	this.urlHashMap["FT240Ah:33"] = "FT240Ah.h:54";
	/* <Root>/Model2 */
	this.urlHashMap["FT240Ah:18"] = "FT240Ah.c:20,33,58&FT240Ah.h:73";
	/* <Root>/Model3 */
	this.urlHashMap["FT240Ah:31"] = "FT240Ah.c:21,36,61&FT240Ah.h:74";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "FT240Ah"};
	this.sidHashMap["FT240Ah"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<Root>/In1"] = {sid: "FT240Ah:22"};
	this.sidHashMap["FT240Ah:22"] = {rtwname: "<Root>/In1"};
	this.rtwnameHashMap["<Root>/In2"] = {sid: "FT240Ah:23"};
	this.sidHashMap["FT240Ah:23"] = {rtwname: "<Root>/In2"};
	this.rtwnameHashMap["<Root>/In7"] = {sid: "FT240Ah:32"};
	this.sidHashMap["FT240Ah:32"] = {rtwname: "<Root>/In7"};
	this.rtwnameHashMap["<Root>/In8"] = {sid: "FT240Ah:33"};
	this.sidHashMap["FT240Ah:33"] = {rtwname: "<Root>/In8"};
	this.rtwnameHashMap["<Root>/Model2"] = {sid: "FT240Ah:18"};
	this.sidHashMap["FT240Ah:18"] = {rtwname: "<Root>/Model2"};
	this.rtwnameHashMap["<Root>/Model3"] = {sid: "FT240Ah:31"};
	this.sidHashMap["FT240Ah:31"] = {rtwname: "<Root>/Model3"};
	this.rtwnameHashMap["<Root>/Out1"] = {sid: "FT240Ah:21"};
	this.sidHashMap["FT240Ah:21"] = {rtwname: "<Root>/Out1"};
	this.rtwnameHashMap["<Root>/Out4"] = {sid: "FT240Ah:34"};
	this.sidHashMap["FT240Ah:34"] = {rtwname: "<Root>/Out4"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
