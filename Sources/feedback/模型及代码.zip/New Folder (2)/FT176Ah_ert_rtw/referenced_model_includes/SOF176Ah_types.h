/*
 * File: SOF176Ah_types.h
 *
 * Code generated for Simulink model 'SOF176Ah'.
 *
 * Model version                  : 1.26
 * Simulink Coder version         : 8.10 (R2016a) 10-Feb-2016
 * C/C++ source code generated on : Tue Dec 20 17:38:14 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SOF176Ah_types_h_
#define RTW_HEADER_SOF176Ah_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_SOF176Ah_T RT_MODEL_SOF176Ah_T;

#endif                                 /* RTW_HEADER_SOF176Ah_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
