/*
 * File: look2_iflf_linlcapw.h
 *
 * Code generated for Simulink model 'Feedback176Ah'.
 *
 * Model version                  : 1.29
 * Simulink Coder version         : 8.10 (R2016a) 10-Feb-2016
 * C/C++ source code generated on : Tue Dec 20 17:38:08 2016
 */

#ifndef SHARE_look2_iflf_linlcapw
#define SHARE_look2_iflf_linlcapw
#include "rtwtypes.h"

extern real32_T look2_iflf_linlcapw(real32_T u0, real32_T u1, const real32_T
  bp0[], const real32_T bp1[], const real32_T table[], const uint32_T maxIndex[],
  uint32_T stride);

#endif

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
